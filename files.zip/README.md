# Campus WiFinder

Find the best Wi-Fi spot on campus — ranked by a neural network trained on
real network telemetry, not a static map. Works from your current location,
or tap any point on the map to get an AI estimate for that exact spot.

## Quick start

Just open `campus_wifinder.html` in a browser. The trained model and a
snapshot of live-ish router conditions are embedded in the page, so it
works with no server at all.

## Running the optional live backend

```bash
pip install -r requirements.txt
python app.py
```

Serves `/api/router-stats` (live predictions for all 70 routers) and
`/api/predict-point?lat=..&lng=..` (AI estimate for any coordinate) on
`http://localhost:5000`.

## Retraining the model

```bash
python train_model.py
```

Reads `router_locations.csv` and `dataset_wifi_extended_renamed_new.csv`,
retrains the neural net, and writes `nn_model.json`, `router_snapshot.json`,
and `wifi_speed_model.pkl`. Run this after updating either CSV, then
re-export the HTML (or just restart `app.py`, which trains fresh on boot).

## How it works

- **Data**: `router_locations.csv` (70 routers, lat/lon) +
  `dataset_wifi_extended_renamed_new.csv` (143k network readings). Every
  reading is matched to its nearest router (haversine nearest-neighbor) so
  each router gets a real history of conditions.
- **Model**: a small feedforward neural network (13 → 12 → 8 → 1, ReLU)
  predicting download speed (Mbps) from signal strength, SNR, noise,
  channel utilization, interference, load, and time-of-day.
- **Arbitrary points**: for a tapped location with no router, the app
  inverse-distance-blends the 3 nearest routers' conditions and runs that
  through the same network.

## Files

| File | What it is |
|---|---|
| `campus_wifinder.html` | The app — frontend + embedded model |
| `app.py` | Optional Flask backend for live predictions |
| `train_model.py` | Trains the model, exports all artifacts |
| `router_locations.csv` | Raw data: router coordinates |
| `dataset_wifi_extended_renamed_new.csv` | Raw data: network readings |
| `nn_model.json` | Trained weights (for the browser-side JS inference) |
| `router_snapshot.json` | Per-router averaged conditions |
| `wifi_speed_model.pkl` | Trained model (for `app.py`) |
